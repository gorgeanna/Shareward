package com.shareward.unityads.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shareward.unityads.ui.theme.AccentCrimson
import com.shareward.unityads.ui.theme.AccentRed
import com.shareward.unityads.ui.theme.GoldCoin

@Composable
fun AdActionButtons(
    isPendingRewarded: Boolean,
    isPendingInterstitial: Boolean,
    onWatchRewardedClick: () -> Unit,
    onShowInterstitialClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ButtonsIdleAnimation")

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "GlowPulse"
    )

    val shimmerOffset by infiniteTransition.animateFloat(
        initialValue = -200f,
        targetValue = 800f,
        animationSpec = infiniteRepeatable(
            animation = tween(2600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ShimmerGradient"
    )

    val giftWiggle by infiniteTransition.animateFloat(
        initialValue = -12f,
        targetValue = 12f,
        animationSpec = infiniteRepeatable(
            animation = tween(350, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "GiftWiggle"
    )

    val tvBounce by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -5f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "TvBounce"
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SpringAnimatedAdButton(
            title = if (isPendingRewarded) "Loading ad..." else "Watch Rewarded Ad (+10 Coins)",
            subtitle = if (isPendingRewarded) "Auto-playing when ready (up to 30s)" else "Instant Reward • Watch Full Video",
            icon = {
                Icon(
                    imageVector = Icons.Default.CardGiftcard,
                    contentDescription = "Rewarded Gift",
                    tint = GoldCoin,
                    modifier = Modifier
                        .size(28.dp)
                        .graphicsLayer {
                            if (!isPendingRewarded) {
                                rotationZ = giftWiggle
                            }
                        }
                )
            },
            gradientColors = listOf(
                Color(0xFFE50914),
                Color(0xFFB71C1C),
                Color(0xFF880E4F)
            ),
            glowColor = AccentRed.copy(alpha = glowAlpha),
            isLoading = isPendingRewarded,
            shimmerOffset = shimmerOffset,
            onClick = onWatchRewardedClick
        )

        SpringAnimatedAdButton(
            title = if (isPendingInterstitial) "Loading ad..." else "Show Interstitial Ad",
            subtitle = if (isPendingInterstitial) "Auto-playing when ready (up to 30s)" else "Full-Screen Experience • Fast Skip",
            icon = {
                Icon(
                    imageVector = Icons.Default.Tv,
                    contentDescription = "Interstitial TV",
                    tint = Color.White,
                    modifier = Modifier
                        .size(28.dp)
                        .graphicsLayer {
                            if (!isPendingInterstitial) {
                                translationY = tvBounce
                            }
                        }
                )
            },
            gradientColors = listOf(
                Color(0xFF7B1FA2),
                Color(0xFF4A148C),
                Color(0xFF1A237E)
            ),
            glowColor = Color(0xFF9C27B0).copy(alpha = glowAlpha * 0.9f),
            isLoading = isPendingInterstitial,
            shimmerOffset = shimmerOffset,
            onClick = onShowInterstitialClick
        )
    }
}

@Composable
private fun SpringAnimatedAdButton(
    title: String,
    subtitle: String,
    icon: @Composable () -> Unit,
    gradientColors: List<Color>,
    glowColor: Color,
    isLoading: Boolean,
    shimmerOffset: Float,
    onClick: () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.94f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "ButtonSpringScale"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .border(
                width = 1.5.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        glowColor,
                        Color.White.copy(alpha = 0.4f),
                        glowColor
                    )
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(colors = gradientColors))
            .pointerInput(isLoading) {
                detectTapGestures(
                    onPress = {
                        if (!isLoading) {
                            isPressed = true
                            tryAwaitRelease()
                            isPressed = false
                        }
                    },
                    onTap = {
                        if (!isLoading) {
                            onClick()
                        }
                    }
                )
            }
            .padding(horizontal = 18.dp, vertical = 16.dp)
    ) {
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.12f),
                            Color.Transparent
                        ),
                        start = Offset(shimmerOffset - 150f, 0f),
                        end = Offset(shimmerOffset + 150f, 100f)
                    )
                )
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.18f))
                        .border(1.dp, Color.White.copy(alpha = 0.35f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = Color.White,
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        icon()
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = title,
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.2.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
