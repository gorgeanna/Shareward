package com.shareward.unityads.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Mouse
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shareward.unityads.ESTIMATED_ECPM_USD
import com.shareward.unityads.data.AdStats
import com.shareward.unityads.ui.theme.GoldCoin
import com.shareward.unityads.ui.theme.TextMuted
import com.shareward.unityads.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun AdPerformanceCard(
    stats: AdStats,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0x3B280720),
                        Color(0x28190738),
                        Color(0x3B0D1326)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0x40E50914),
                        Color(0x26FFFFFF)
                    )
                ),
                shape = RoundedCornerShape(24.dp)
            )
            .padding(20.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0x33FFB300)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AttachMoney,
                        contentDescription = "Performance",
                        tint = GoldCoin,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Ad Performance & Metrics",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Live counters saved in DataStore (persists after restart)",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile(
                    title = "TOTAL AD CLICKS",
                    rawValue = stats.clicks,
                    icon = Icons.Default.Mouse,
                    accentColor = Color(0xFF38BDF8),
                    gradient = listOf(Color(0x330284C7), Color(0x1F0369A1)),
                    modifier = Modifier.weight(1f)
                )
                MetricTileDouble(
                    title = "CTR %",
                    value = stats.ctrPercent,
                    suffix = "%",
                    icon = Icons.Default.Percent,
                    accentColor = Color(0xFFA855F7),
                    gradient = listOf(Color(0x337E22CE), Color(0x1F6B21A8)),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile(
                    title = "REWARDED WATCHED",
                    rawValue = stats.rewardedWatched,
                    icon = Icons.Default.VideoLibrary,
                    accentColor = Color(0xFF10B981),
                    gradient = listOf(Color(0x33059669), Color(0x1F047857)),
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    title = "INTERSTITIALS SHOWN",
                    rawValue = stats.interstitialsShown,
                    icon = Icons.Default.Tv,
                    accentColor = Color(0xFFF59E0B),
                    gradient = listOf(Color(0x33D97706), Color(0x1FB45309)),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile(
                    title = "ADS SKIPPED",
                    rawValue = stats.adsSkipped,
                    icon = Icons.Default.SkipNext,
                    accentColor = Color(0xFFEF4444),
                    gradient = listOf(Color(0x33DC2626), Color(0x1FB91C1C)),
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    title = "TOTAL COINS EARNED",
                    rawValue = stats.coins,
                    icon = Icons.Default.MonetizationOn,
                    accentColor = GoldCoin,
                    gradient = listOf(Color(0x33B45309), Color(0x1F78350F)),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile(
                    title = "LOAD SUCCESS",
                    rawValue = stats.loadSuccess,
                    icon = Icons.Default.CheckCircle,
                    accentColor = Color(0xFF34D399),
                    gradient = listOf(Color(0x28047857), Color(0x15065F46)),
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    title = "LOAD FAILED",
                    rawValue = stats.loadFailed,
                    icon = Icons.Default.ErrorOutline,
                    accentColor = Color(0xFFF87171),
                    gradient = listOf(Color(0x28991B1B), Color(0x157F1D1D)),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            val estimatedEarnings = stats.estimatedEarningsUsd(ESTIMATED_ECPM_USD)
            val animatedEarnings by animateFloatAsState(
                targetValue = estimatedEarnings.toFloat(),
                animationSpec = tween(700, easing = FastOutSlowInEasing),
                label = "AnimatedEarnings"
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                Color(0x4010B981),
                                Color(0x26047857),
                                Color(0x35064E3B)
                            )
                        )
                    )
                    .border(1.dp, Color(0x4D34D399), RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "ESTIMATED EARNINGS",
                            color = Color(0xFFA7F3D0),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "$${String.format(Locale.US, "%.4f", animatedEarnings)} USD",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Formula: (Impressions / 1000) * $$ESTIMATED_ECPM_USD eCPM",
                            color = Color(0xCC6EE7B7),
                            fontSize = 10.sp
                        )
                        Text(
                            text = "Estimated (check Unity Dashboard for real earnings)",
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0x3310B981)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AttachMoney,
                            contentDescription = null,
                            tint = Color(0xFF34D399),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricTile(
    title: String,
    rawValue: Int,
    icon: ImageVector,
    accentColor: Color,
    gradient: List<Color>,
    modifier: Modifier = Modifier
) {
    val animatedValue by animateIntAsState(
        targetValue = rawValue,
        animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "MetricInt"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(gradient))
            .border(1.dp, Color(0x20FFFFFF), RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "$animatedValue",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun MetricTileDouble(
    title: String,
    value: Double,
    suffix: String,
    icon: ImageVector,
    accentColor: Color,
    gradient: List<Color>,
    modifier: Modifier = Modifier
) {
    val animatedValue by animateFloatAsState(
        targetValue = value.toFloat(),
        animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "MetricFloat"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(gradient))
            .border(1.dp, Color(0x20FFFFFF), RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "${String.format(Locale.US, "%.1f", animatedValue)}$suffix",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
