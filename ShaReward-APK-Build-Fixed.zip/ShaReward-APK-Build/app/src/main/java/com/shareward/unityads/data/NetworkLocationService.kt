package com.shareward.unityads.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class NetworkLocationInfo(
    val ip: String,
    val country: String,
    val countryCode: String,
    val flagEmoji: String,
    val region: String,
    val city: String,
    val isp: String,
    val timezone: String
)

sealed class NetworkLocationState {
    object Idle : NetworkLocationState()
    object Loading : NetworkLocationState()
    data class Success(val info: NetworkLocationInfo) : NetworkLocationState()
    data class Error(val message: String) : NetworkLocationState()
}

class NetworkLocationService {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    suspend fun fetchLocation(): NetworkLocationState = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("https://ipwho.is/")
                .header("User-Agent", "ShaReward-Android/1.0")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext NetworkLocationState.Error("HTTP Error: ${response.code}")
                }

                val bodyString = response.body?.string() ?: return@withContext NetworkLocationState.Error("Empty response body")
                val json = JSONObject(bodyString)

                val success = json.optBoolean("success", true)
                if (!success) {
                    val message = json.optString("message", "IP lookup failed")
                    return@withContext NetworkLocationState.Error(message)
                }

                val ip = json.optString("ip", "Unknown")
                val country = json.optString("country", "Unknown")
                val countryCode = json.optString("country_code", "")
                val region = json.optString("region", "Unknown")
                val city = json.optString("city", "Unknown")

                val flagObj = json.optJSONObject("flag")
                val flagEmoji = flagObj?.optString("emoji") ?: getFlagEmojiFromCountryCode(countryCode)

                val connectionObj = json.optJSONObject("connection")
                val isp = connectionObj?.optString("isp") ?: json.optString("isp", "Unknown ISP")

                val timezoneObj = json.optJSONObject("timezone")
                val tzId = timezoneObj?.optString("id", "")
                val tzUtc = timezoneObj?.optString("utc", "")
                val timezone = if (tzId.isNotBlank()) "$tzId ($tzUtc)" else "UTC"

                NetworkLocationState.Success(
                    NetworkLocationInfo(
                        ip = ip,
                        country = country,
                        countryCode = countryCode,
                        flagEmoji = flagEmoji,
                        region = region,
                        city = city,
                        isp = isp,
                        timezone = timezone
                    )
                )
            }
        } catch (e: Exception) {
            NetworkLocationState.Error(e.localizedMessage ?: "Failed to reach network diagnostics service")
        }
    }

    private fun getFlagEmojiFromCountryCode(countryCode: String): String {
        if (countryCode.length != 2) return "🌐"
        val firstChar = Character.codePointAt(countryCode.uppercase(), 0) - 0x41 + 0x1F1E6
        val secondChar = Character.codePointAt(countryCode.uppercase(), 1) - 0x41 + 0x1F1E6
        return String(Character.toChars(firstChar)) + String(Character.toChars(secondChar))
    }
}
