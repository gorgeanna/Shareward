package com.shareward.unityads

import android.app.Activity
import android.content.Context
import com.shareward.unityads.data.AdStatsRepository
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class SdkStatus {
    object Uninitialized : SdkStatus()
    object Initializing : SdkStatus()
    object Initialized : SdkStatus()
    data class Failed(val errorCode: String, val rawMessage: String) : SdkStatus()
}

sealed class AdPlacementState {
    object Idle : AdPlacementState()
    object Loading : AdPlacementState()
    object Ready : AdPlacementState()
    object Showing : AdPlacementState()
    data class Error(val errorCode: String, val rawMessage: String) : AdPlacementState()
}

sealed class UiEvent {
    data class ShowSnackbar(val message: String) : UiEvent()
    data class RewardCelebration(val coinsEarned: Int) : UiEvent()
}

class UnityAdsManager(
    private val context: Context,
    private val adStatsRepository: AdStatsRepository
) {
    private val managerScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val _sdkStatus = MutableStateFlow<SdkStatus>(SdkStatus.Uninitialized)
    val sdkStatus: StateFlow<SdkStatus> = _sdkStatus.asStateFlow()

    private val _rewardedState = MutableStateFlow<AdPlacementState>(AdPlacementState.Idle)
    val rewardedState: StateFlow<AdPlacementState> = _rewardedState.asStateFlow()

    private val _interstitialState = MutableStateFlow<AdPlacementState>(AdPlacementState.Idle)
    val interstitialState: StateFlow<AdPlacementState> = _interstitialState.asStateFlow()

    private val _lastRawError = MutableStateFlow<String?>(null)
    val lastRawError: StateFlow<String?> = _lastRawError.asStateFlow()

    private val _isPendingRewarded = MutableStateFlow(false)
    val isPendingRewarded: StateFlow<Boolean> = _isPendingRewarded.asStateFlow()

    private val _isPendingInterstitial = MutableStateFlow(false)
    val isPendingInterstitial: StateFlow<Boolean> = _isPendingInterstitial.asStateFlow()

    private val _events = MutableSharedFlow<UiEvent>()
    val events: SharedFlow<UiEvent> = _events.asSharedFlow()

    private var rewardedRetryJob: Job? = null
    private var interstitialRetryJob: Job? = null

    private var pendingRewardedJob: Job? = null
    private var pendingInterstitialJob: Job? = null
    private var pendingActivity: Activity? = null

    fun initialize() {
        if (_sdkStatus.value is SdkStatus.Initializing || _sdkStatus.value is SdkStatus.Initialized) {
            return
        }

        _sdkStatus.value = SdkStatus.Initializing

        UnityAds.initialize(
            context.applicationContext,
            UNITY_GAME_ID,
            TEST_MODE,
            object : IUnityAdsInitializationListener {
                override fun onInitializationComplete() {
                    _sdkStatus.value = SdkStatus.Initialized
                    _lastRawError.value = null
                    loadRewardedAd()
                    loadInterstitialAd()
                }

                override fun onInitializationFailed(
                    error: UnityAds.UnityAdsInitializationError,
                    message: String
                ) {
                    val rawErr = "Init Failed: [${error.name}] $message"
                    _sdkStatus.value = SdkStatus.Failed(error.name, message)
                    _lastRawError.value = rawErr
                }
            }
        )
    }

    fun reloadAllAds() {
        loadRewardedAd()
        loadInterstitialAd()
    }

    fun loadRewardedAd() {
        rewardedRetryJob?.cancel()
        _rewardedState.value = AdPlacementState.Loading

        UnityAds.load(
            REWARDED_PLACEMENT_ID,
            object : IUnityAdsLoadListener {
                override fun onUnityAdsAdLoaded(placementId: String) {
                    _rewardedState.value = AdPlacementState.Ready
                    managerScope.launch {
                        adStatsRepository.recordLoadSuccess()
                    }

                    if (_isPendingRewarded.value) {
                        pendingRewardedJob?.cancel()
                        _isPendingRewarded.value = false
                        val activity = pendingActivity
                        if (activity != null && !activity.isFinishing && !activity.isDestroyed) {
                            showRewardedAd(activity)
                        }
                    }
                }

                override fun onUnityAdsFailedToLoad(
                    placementId: String,
                    error: UnityAds.UnityAdsLoadError,
                    message: String
                ) {
                    val rawErr = "Rewarded Load Error: [${error.name}] $message"
                    _rewardedState.value = AdPlacementState.Error(error.name, message)
                    _lastRawError.value = rawErr

                    managerScope.launch {
                        adStatsRepository.recordLoadFailed()
                    }

                    rewardedRetryJob = managerScope.launch {
                        delay(5000L)
                        loadRewardedAd()
                    }
                }
            }
        )
    }

    fun loadInterstitialAd() {
        interstitialRetryJob?.cancel()
        _interstitialState.value = AdPlacementState.Loading

        UnityAds.load(
            INTERSTITIAL_PLACEMENT_ID,
            object : IUnityAdsLoadListener {
                override fun onUnityAdsAdLoaded(placementId: String) {
                    _interstitialState.value = AdPlacementState.Ready
                    managerScope.launch {
                        adStatsRepository.recordLoadSuccess()
                    }

                    if (_isPendingInterstitial.value) {
                        pendingInterstitialJob?.cancel()
                        _isPendingInterstitial.value = false
                        val activity = pendingActivity
                        if (activity != null && !activity.isFinishing && !activity.isDestroyed) {
                            showInterstitialAd(activity)
                        }
                    }
                }

                override fun onUnityAdsFailedToLoad(
                    placementId: String,
                    error: UnityAds.UnityAdsLoadError,
                    message: String
                ) {
                    val rawErr = "Interstitial Load Error: [${error.name}] $message"
                    _interstitialState.value = AdPlacementState.Error(error.name, message)
                    _lastRawError.value = rawErr

                    managerScope.launch {
                        adStatsRepository.recordLoadFailed()
                    }

                    interstitialRetryJob = managerScope.launch {
                        delay(5000L)
                        loadInterstitialAd()
                    }
                }
            }
        )
    }

    fun onRewardedButtonClicked(activity: Activity) {
        if (_isPendingRewarded.value || _rewardedState.value is AdPlacementState.Showing) return

        if (_rewardedState.value is AdPlacementState.Ready) {
            showRewardedAd(activity)
        } else {
            _isPendingRewarded.value = true
            pendingActivity = activity

            if (_rewardedState.value !is AdPlacementState.Loading) {
                loadRewardedAd()
            }

            pendingRewardedJob?.cancel()
            pendingRewardedJob = managerScope.launch {
                delay(30_000L)
                if (_isPendingRewarded.value) {
                    _isPendingRewarded.value = false
                    _events.emit(UiEvent.ShowSnackbar("No ad available right now, please try again"))
                }
            }
        }
    }

    fun onInterstitialButtonClicked(activity: Activity) {
        if (_isPendingInterstitial.value || _interstitialState.value is AdPlacementState.Showing) return

        if (_interstitialState.value is AdPlacementState.Ready) {
            showInterstitialAd(activity)
        } else {
            _isPendingInterstitial.value = true
            pendingActivity = activity

            if (_interstitialState.value !is AdPlacementState.Loading) {
                loadInterstitialAd()
            }

            pendingInterstitialJob?.cancel()
            pendingInterstitialJob = managerScope.launch {
                delay(30_000L)
                if (_isPendingInterstitial.value) {
                    _isPendingInterstitial.value = false
                    _events.emit(UiEvent.ShowSnackbar("No ad available right now, please try again"))
                }
            }
        }
    }

    private fun showRewardedAd(activity: Activity) {
        _rewardedState.value = AdPlacementState.Showing

        UnityAds.show(
            activity,
            REWARDED_PLACEMENT_ID,
            UnityAdsShowOptions(),
            object : IUnityAdsShowListener {
                override fun onUnityAdsShowFailure(
                    placementId: String,
                    error: UnityAds.UnityAdsShowError,
                    message: String
                ) {
                    val rawErr = "Show Rewarded Error: [${error.name}] $message"
                    _rewardedState.value = AdPlacementState.Error(error.name, message)
                    _lastRawError.value = rawErr

                    managerScope.launch {
                        _events.emit(UiEvent.ShowSnackbar("Ad playback failed: $message"))
                    }
                    loadRewardedAd()
                }

                override fun onUnityAdsShowStart(placementId: String) {
                    _rewardedState.value = AdPlacementState.Showing
                }

                override fun onUnityAdsShowClick(placementId: String) {
                    managerScope.launch {
                        adStatsRepository.recordClick()
                    }
                }

                override fun onUnityAdsShowComplete(
                    placementId: String,
                    state: UnityAds.UnityAdsShowCompletionState
                ) {
                    if (state == UnityAds.UnityAdsShowCompletionState.COMPLETED) {
                        managerScope.launch {
                            adStatsRepository.recordRewardedWatched(REWARD_COINS_PER_AD)
                            _events.emit(UiEvent.RewardCelebration(REWARD_COINS_PER_AD))
                            _events.emit(UiEvent.ShowSnackbar("🎉 Congratulations! +$REWARD_COINS_PER_AD Coins credited to balance!"))
                        }
                    } else {
                        managerScope.launch {
                            adStatsRepository.recordAdSkipped()
                            _events.emit(UiEvent.ShowSnackbar("Ad was skipped. No coins rewarded."))
                        }
                    }
                    _rewardedState.value = AdPlacementState.Idle
                    loadRewardedAd()
                }
            }
        )
    }

    private fun showInterstitialAd(activity: Activity) {
        _interstitialState.value = AdPlacementState.Showing

        UnityAds.show(
            activity,
            INTERSTITIAL_PLACEMENT_ID,
            UnityAdsShowOptions(),
            object : IUnityAdsShowListener {
                override fun onUnityAdsShowFailure(
                    placementId: String,
                    error: UnityAds.UnityAdsShowError,
                    message: String
                ) {
                    val rawErr = "Show Interstitial Error: [${error.name}] $message"
                    _interstitialState.value = AdPlacementState.Error(error.name, message)
                    _lastRawError.value = rawErr

                    managerScope.launch {
                        _events.emit(UiEvent.ShowSnackbar("Ad playback failed: $message"))
                    }
                    loadInterstitialAd()
                }

                override fun onUnityAdsShowStart(placementId: String) {
                    _interstitialState.value = AdPlacementState.Showing
                }

                override fun onUnityAdsShowClick(placementId: String) {
                    managerScope.launch {
                        adStatsRepository.recordClick()
                    }
                }

                override fun onUnityAdsShowComplete(
                    placementId: String,
                    state: UnityAds.UnityAdsShowCompletionState
                ) {
                    managerScope.launch {
                        if (state == UnityAds.UnityAdsShowCompletionState.COMPLETED) {
                            adStatsRepository.recordInterstitialShown()
                        } else {
                            adStatsRepository.recordAdSkipped()
                        }
                    }
                    _interstitialState.value = AdPlacementState.Idle
                    loadInterstitialAd()
                }
            }
        )
    }
}
