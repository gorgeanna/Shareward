package com.shareward.unityads.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "ad_stats_prefs")

data class AdStats(
    val coins: Int = 0,
    val clicks: Int = 0,
    val rewardedWatched: Int = 0,
    val interstitialsShown: Int = 0,
    val adsSkipped: Int = 0,
    val loadSuccess: Int = 0,
    val loadFailed: Int = 0
) {
    val totalImpressions: Int
        get() = rewardedWatched + interstitialsShown

    val ctrPercent: Double
        get() = if (totalImpressions > 0) (clicks.toDouble() / totalImpressions.toDouble()) * 100.0 else 0.0

    fun estimatedEarningsUsd(ecpmUsd: Double): Double {
        return (totalImpressions.toDouble() / 1000.0) * ecpmUsd
    }
}

class AdStatsRepository(private val context: Context) {

    private object PreferencesKeys {
        val KEY_COINS = intPreferencesKey("user_coins")
        val KEY_CLICKS = intPreferencesKey("total_ad_clicks")
        val KEY_REWARDED_WATCHED = intPreferencesKey("rewarded_watched")
        val KEY_INTERSTITIALS_SHOWN = intPreferencesKey("interstitials_shown")
        val KEY_ADS_SKIPPED = intPreferencesKey("ads_skipped")
        val KEY_LOAD_SUCCESS = intPreferencesKey("load_success")
        val KEY_LOAD_FAILED = intPreferencesKey("load_failed")
    }

    val adStatsFlow: Flow<AdStats> = context.dataStore.data.map { preferences ->
        AdStats(
            coins = preferences[PreferencesKeys.KEY_COINS] ?: 0,
            clicks = preferences[PreferencesKeys.KEY_CLICKS] ?: 0,
            rewardedWatched = preferences[PreferencesKeys.KEY_REWARDED_WATCHED] ?: 0,
            interstitialsShown = preferences[PreferencesKeys.KEY_INTERSTITIALS_SHOWN] ?: 0,
            adsSkipped = preferences[PreferencesKeys.KEY_ADS_SKIPPED] ?: 0,
            loadSuccess = preferences[PreferencesKeys.KEY_LOAD_SUCCESS] ?: 0,
            loadFailed = preferences[PreferencesKeys.KEY_LOAD_FAILED] ?: 0
        )
    }

    suspend fun addCoins(amount: Int) {
        context.dataStore.edit { preferences ->
            val current = preferences[PreferencesKeys.KEY_COINS] ?: 0
            preferences[PreferencesKeys.KEY_COINS] = current + amount
        }
    }

    suspend fun recordClick() {
        context.dataStore.edit { preferences ->
            val current = preferences[PreferencesKeys.KEY_CLICKS] ?: 0
            preferences[PreferencesKeys.KEY_CLICKS] = current + 1
        }
    }

    suspend fun recordRewardedWatched(coinsReward: Int) {
        context.dataStore.edit { preferences ->
            val currentWatched = preferences[PreferencesKeys.KEY_REWARDED_WATCHED] ?: 0
            preferences[PreferencesKeys.KEY_REWARDED_WATCHED] = currentWatched + 1

            val currentCoins = preferences[PreferencesKeys.KEY_COINS] ?: 0
            preferences[PreferencesKeys.KEY_COINS] = currentCoins + coinsReward
        }
    }

    suspend fun recordInterstitialShown() {
        context.dataStore.edit { preferences ->
            val current = preferences[PreferencesKeys.KEY_INTERSTITIALS_SHOWN] ?: 0
            preferences[PreferencesKeys.KEY_INTERSTITIALS_SHOWN] = current + 1
        }
    }

    suspend fun recordAdSkipped() {
        context.dataStore.edit { preferences ->
            val current = preferences[PreferencesKeys.KEY_ADS_SKIPPED] ?: 0
            preferences[PreferencesKeys.KEY_ADS_SKIPPED] = current + 1
        }
    }

    suspend fun recordLoadSuccess() {
        context.dataStore.edit { preferences ->
            val current = preferences[PreferencesKeys.KEY_LOAD_SUCCESS] ?: 0
            preferences[PreferencesKeys.KEY_LOAD_SUCCESS] = current + 1
        }
    }

    suspend fun recordLoadFailed() {
        context.dataStore.edit { preferences ->
            val current = preferences[PreferencesKeys.KEY_LOAD_FAILED] ?: 0
            preferences[PreferencesKeys.KEY_LOAD_FAILED] = current + 1
        }
    }

    suspend fun resetAllStats() {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.KEY_COINS] = 0
            preferences[PreferencesKeys.KEY_CLICKS] = 0
            preferences[PreferencesKeys.KEY_REWARDED_WATCHED] = 0
            preferences[PreferencesKeys.KEY_INTERSTITIALS_SHOWN] = 0
            preferences[PreferencesKeys.KEY_ADS_SKIPPED] = 0
            preferences[PreferencesKeys.KEY_LOAD_SUCCESS] = 0
            preferences[PreferencesKeys.KEY_LOAD_FAILED] = 0
        }
    }
}
