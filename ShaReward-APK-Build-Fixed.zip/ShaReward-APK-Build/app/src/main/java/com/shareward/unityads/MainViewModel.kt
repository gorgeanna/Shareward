package com.shareward.unityads

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shareward.unityads.data.AdStats
import com.shareward.unityads.data.AdStatsRepository
import com.shareward.unityads.data.NetworkLocationService
import com.shareward.unityads.data.NetworkLocationState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val adStatsRepository = AdStatsRepository(application)
    private val networkLocationService = NetworkLocationService()
    val adsManager = UnityAdsManager(application, adStatsRepository)

    val adStats: StateFlow<AdStats> = adStatsRepository.adStatsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AdStats()
    )

    val sdkStatus: StateFlow<SdkStatus> = adsManager.sdkStatus
    val rewardedState: StateFlow<AdPlacementState> = adsManager.rewardedState
    val interstitialState: StateFlow<AdPlacementState> = adsManager.interstitialState
    val lastRawError: StateFlow<String?> = adsManager.lastRawError
    val isPendingRewarded: StateFlow<Boolean> = adsManager.isPendingRewarded
    val isPendingInterstitial: StateFlow<Boolean> = adsManager.isPendingInterstitial
    val events = adsManager.events

    private val _networkLocationState = MutableStateFlow<NetworkLocationState>(NetworkLocationState.Idle)
    val networkLocationState: StateFlow<NetworkLocationState> = _networkLocationState.asStateFlow()

    private val _sessionDurationSeconds = MutableStateFlow(0L)
    val sessionDurationSeconds: StateFlow<Long> = _sessionDurationSeconds.asStateFlow()

    init {
        adsManager.initialize()
        refreshNetworkLocation()
        startSessionTimer()
    }

    private fun startSessionTimer() {
        viewModelScope.launch {
            while (isActive) {
                delay(1000L)
                _sessionDurationSeconds.value += 1L
            }
        }
    }

    fun refreshNetworkLocation() {
        viewModelScope.launch {
            _networkLocationState.value = NetworkLocationState.Loading
            _networkLocationState.value = networkLocationService.fetchLocation()
        }
    }

    fun onRewardedClick(activity: Activity) {
        adsManager.onRewardedButtonClicked(activity)
    }

    fun onInterstitialClick(activity: Activity) {
        adsManager.onInterstitialButtonClicked(activity)
    }

    fun reloadAds() {
        adsManager.reloadAllAds()
    }

    fun resetStats() {
        viewModelScope.launch {
            adStatsRepository.resetAllStats()
        }
    }
}
