package com.shareward.unityads.ui.theme

import androidx.compose.ui.graphics.Color

val BgDeepPurple = Color(0xFF130924)
val BgDarkNavy = Color(0xFF090D18)
val BgCardGlass = Color(0x2AFFFFFF)
val BgCardGlassRed = Color(0x33B71C1C)
val BorderGlass = Color(0x26FFFFFF)
val BorderGlassRed = Color(0x4DE50914)

val AccentRed = Color(0xFFE50914)
val AccentRedDark = Color(0xFF990000)
val AccentCrimson = Color(0xFFFF2A4D)

val GoldCoin = Color(0xFFFFD700)
val GoldCoinDark = Color(0xFFFFA500)

val StatusGreen = Color(0xFF10B981)
val StatusYellow = Color(0xFFF59E0B)
val StatusRed = Color(0xFFEF4444)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB0B9C6)
val TextMuted = Color(0xFF758295)
