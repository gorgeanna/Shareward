package com.shareward.unityads.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.random.Random

private data class Particle(
    val startX: Float,
    val startY: Float,
    val velocityX: Float,
    val velocityY: Float,
    val color: Color,
    val size: Float,
    val isCoin: Boolean
)

@Composable
fun ConfettiOverlay(
    trigger: Long,
    modifier: Modifier = Modifier
) {
    if (trigger <= 0) return

    val progress = remember(trigger) { Animatable(0f) }

    val particles = remember(trigger) {
        val colors = listOf(
            Color(0xFFFFD700),
            Color(0xFFFFA500),
            Color(0xFFE50914),
            Color(0xFFFF4081),
            Color(0xFF00E676),
            Color(0xFF00B0FF)
        )
        List(45) {
            Particle(
                startX = Random.nextFloat(),
                startY = -0.1f - Random.nextFloat() * 0.2f,
                velocityX = (Random.nextFloat() - 0.5f) * 0.4f,
                velocityY = 0.8f + Random.nextFloat() * 0.6f,
                color = colors[Random.nextInt(colors.size)],
                size = 10f + Random.nextFloat() * 14f,
                isCoin = Random.nextBoolean()
            )
        }
    }

    LaunchedEffect(trigger) {
        progress.snapTo(0f)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 2400, easing = LinearEasing)
        )
    }

    if (progress.value in 0.001f..0.999f) {
        Canvas(modifier = modifier.fillMaxSize()) {
            val p = progress.value
            val width = size.width
            val height = size.height

            particles.forEach { particle ->
                val currentX = (particle.startX + particle.velocityX * p) * width
                val currentY = (particle.startY + particle.velocityY * p + 0.5f * 9.8f * p * p * 0.15f) * height
                val alpha = (1f - p).coerceIn(0f, 1f)

                if (particle.isCoin) {
                    drawCircle(
                        color = particle.color.copy(alpha = alpha),
                        radius = particle.size * 0.8f,
                        center = Offset(currentX, currentY)
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = alpha * 0.7f),
                        radius = particle.size * 0.35f,
                        center = Offset(currentX, currentY)
                    )
                } else {
                    drawRect(
                        color = particle.color.copy(alpha = alpha),
                        topLeft = Offset(currentX, currentY),
                        size = androidx.compose.ui.geometry.Size(particle.size, particle.size * 0.6f)
                    )
                }
            }
        }
    }
}
