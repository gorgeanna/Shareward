package com.shareward.unityads.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shareward.unityads.AdPlacementState
import com.shareward.unityads.SdkStatus
import com.shareward.unityads.UNITY_GAME_ID
import com.shareward.unityads.ui.theme.StatusGreen
import com.shareward.unityads.ui.theme.StatusRed
import com.shareward.unityads.ui.theme.StatusYellow
import com.shareward.unityads.ui.theme.TextMuted
import com.shareward.unityads.ui.theme.TextSecondary

@Composable
fun AdsEngineStatusCard(
    sdkStatus: SdkStatus,
    rewardedState: AdPlacementState,
    interstitialState: AdPlacementState,
    lastRawError: String?,
    onReloadAds: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0x2E1C0A35),
                        Color(0x3B2C0514),
                        Color(0x280D111A)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0x40E50914),
                        Color(0x26FFFFFF)
                    )
                ),
                shape = RoundedCornerShape(24.dp)
            )
            .padding(20.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0x33E50914)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Hub,
                            contentDescription = "Engine Status",
                            tint = Color(0xFFFF4560),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Ads Engine Telemetry",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Game ID: $UNITY_GAME_ID",
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                OutlinedButton(
                    onClick = onReloadAds,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = Color(0x22FFFFFF),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Cached,
                        contentDescription = "Reload",
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Reload Ads",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            StatusRow(
                label = "Unity SDK 4.21.0 Core",
                statusText = when (sdkStatus) {
                    is SdkStatus.Uninitialized -> "Uninitialized"
                    is SdkStatus.Initializing -> "Initializing..."
                    is SdkStatus.Initialized -> "Initialized & Operational"
                    is SdkStatus.Failed -> "Init Failure: ${sdkStatus.errorCode}"
                },
                dotColor = when (sdkStatus) {
                    is SdkStatus.Uninitialized -> Color.Gray
                    is SdkStatus.Initializing -> StatusYellow
                    is SdkStatus.Initialized -> StatusGreen
                    is SdkStatus.Failed -> StatusRed
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            StatusRow(
                label = "Rewarded Placement (Rewarded_Android)",
                statusText = when (rewardedState) {
                    is AdPlacementState.Idle -> "Idle"
                    is AdPlacementState.Loading -> "Loading video stream..."
                    is AdPlacementState.Ready -> "Ready to Display"
                    is AdPlacementState.Showing -> "Playing on screen"
                    is AdPlacementState.Error -> "Failed: ${rewardedState.errorCode}"
                },
                dotColor = when (rewardedState) {
                    is AdPlacementState.Idle -> Color.Gray
                    is AdPlacementState.Loading -> StatusYellow
                    is AdPlacementState.Ready -> StatusGreen
                    is AdPlacementState.Showing -> Color(0xFF38BDF8)
                    is AdPlacementState.Error -> StatusRed
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            StatusRow(
                label = "Interstitial Placement (Interstitial_Android)",
                statusText = when (interstitialState) {
                    is AdPlacementState.Idle -> "Idle"
                    is AdPlacementState.Loading -> "Loading interstitial stream..."
                    is AdPlacementState.Ready -> "Ready to Display"
                    is AdPlacementState.Showing -> "Playing on screen"
                    is AdPlacementState.Error -> "Failed: ${interstitialState.errorCode}"
                },
                dotColor = when (interstitialState) {
                    is AdPlacementState.Idle -> Color.Gray
                    is AdPlacementState.Loading -> StatusYellow
                    is AdPlacementState.Ready -> StatusGreen
                    is AdPlacementState.Showing -> Color(0xFF38BDF8)
                    is AdPlacementState.Error -> StatusRed
                }
            )

            AnimatedVisibility(visible = lastRawError != null) {
                Column(modifier = Modifier.padding(top = 16.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x38450A0A))
                            .border(1.dp, Color(0x66EF4444), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.WarningAmber,
                                    contentDescription = "Error",
                                    tint = StatusRed,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "RAW UNITY SDK ERROR (Exact Response)",
                                    color = Color(0xFFFCA5A5),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = lastRawError ?: "",
                                color = Color(0xFFFEE2E2),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusRow(
    label: String,
    statusText: String,
    dotColor: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0x1AFFFFFF))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = statusText,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
    }
}
