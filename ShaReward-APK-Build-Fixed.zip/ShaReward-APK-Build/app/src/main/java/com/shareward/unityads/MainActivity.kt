package com.shareward.unityads

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shareward.unityads.ui.components.AdActionButtons
import com.shareward.unityads.ui.components.AdPerformanceCard
import com.shareward.unityads.ui.components.AdsEngineStatusCard
import com.shareward.unityads.ui.components.CoinBalanceCard
import com.shareward.unityads.ui.components.ConfettiOverlay
import com.shareward.unityads.ui.components.DeviceSessionCard
import com.shareward.unityads.ui.components.HeaderCard
import com.shareward.unityads.ui.components.NetworkLocationCard
import com.shareward.unityads.ui.theme.BgDarkNavy
import com.shareward.unityads.ui.theme.BgDeepPurple
import com.shareward.unityads.ui.theme.ShaRewardTheme
import com.shareward.unityads.ui.theme.TextMuted
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            ShaRewardTheme {
                MainScreen(
                    viewModel = viewModel,
                    activity = this
                )
            }
        }
    }
}

@Composable
fun MainScreen(
    viewModel: MainViewModel,
    activity: ComponentActivity
) {
    val scrollState = rememberScrollState()
    val snackbarHostState = remember { SnackbarHostState() }

    val adStats by viewModel.adStats.collectAsState()
    val sdkStatus by viewModel.sdkStatus.collectAsState()
    val rewardedState by viewModel.rewardedState.collectAsState()
    val interstitialState by viewModel.interstitialState.collectAsState()
    val lastRawError by viewModel.lastRawError.collectAsState()
    val isPendingRewarded by viewModel.isPendingRewarded.collectAsState()
    val isPendingInterstitial by viewModel.isPendingInterstitial.collectAsState()
    val networkLocationState by viewModel.networkLocationState.collectAsState()
    val sessionSeconds by viewModel.sessionDurationSeconds.collectAsState()

    var confettiTrigger by remember { mutableStateOf(0L) }

    LaunchedEffect(Unit) {
        viewModel.events.collectLatest { event ->
            when (event) {
                is UiEvent.ShowSnackbar -> {
                    snackbarHostState.showSnackbar(event.message)
                }
                is UiEvent.RewardCelebration -> {
                    confettiTrigger = System.currentTimeMillis()
                }
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = Color.Transparent
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            BgDeepPurple,
                            Color(0xFF1B0B2E),
                            Color(0xFF0F0E24),
                            BgDarkNavy
                        )
                    )
                )
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                HeaderCard()
                CoinBalanceCard(coins = adStats.coins)
                AdActionButtons(
                    isPendingRewarded = isPendingRewarded,
                    isPendingInterstitial = isPendingInterstitial,
                    onWatchRewardedClick = { viewModel.onRewardedClick(activity) },
                    onShowInterstitialClick = { viewModel.onInterstitialClick(activity) }
                )
                AdsEngineStatusCard(
                    sdkStatus = sdkStatus,
                    rewardedState = rewardedState,
                    interstitialState = interstitialState,
                    lastRawError = lastRawError,
                    onReloadAds = { viewModel.reloadAds() }
                )
                NetworkLocationCard(
                    locationState = networkLocationState,
                    onRefresh = { viewModel.refreshNetworkLocation() }
                )
                AdPerformanceCard(stats = adStats)
                DeviceSessionCard(
                    sessionSeconds = sessionSeconds,
                    onResetStats = { viewModel.resetStats() }
                )
                AppFooter()
                Spacer(modifier = Modifier.height(16.dp))
            }

            ConfettiOverlay(trigger = confettiTrigger)
        }
    }
}

@Composable
private fun AppFooter() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (TEST_MODE) Color(0xFFF59E0B) else Color(0xFF10B981))
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (TEST_MODE) "TEST ENVIRONMENT" else "PRODUCTION ENVIRONMENT",
                color = if (TEST_MODE) Color(0xFFFBBF24) else Color(0xFF34D399),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = PACKAGE_NAME,
            color = TextMuted,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = "Engineered with Jetpack Compose & Unity Ads SDK 4.21.0",
            color = Color.White.copy(alpha = 0.35f),
            fontSize = 10.sp
        )
    }
}
