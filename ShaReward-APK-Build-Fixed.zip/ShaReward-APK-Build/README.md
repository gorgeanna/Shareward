# ShaReward - Native Android Unity Ads Production Suite

A complete Native Android application built with **Kotlin**, **Jetpack Compose (Material 3)**, and **Unity Ads SDK 4.21.0**.

## Specifications
- **Application ID**: com.shareward.unityads
- **Unity Game ID**: 800410382
- **Rewarded Placement**: Rewarded_Android
- **Interstitial Placement**: Interstitial_Android
- **minSdk**: 24 | **targetSdk**: 34
- **Orientation**: Portrait only
- **Persistence**: Jetpack DataStore Preferences

## How to Build in Android Studio
1. Open Android Studio (Hedgehog, Iguana, Jellyfish, or Koala).
2. Click **Open** and select this extracted directory.
3. Wait for Gradle Sync to complete.
4. Go to **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
5. Transfer the output APK from `app/build/outputs/apk/debug/app-debug.apk` to your Android phone and install!
